# Ton 1
### Pechmarie
Aard wuchs auf mit Musik, aber jede Aufführung war von Unglück geplagt, das Publikum hasste ihn. Aard kam immer davon, begleitet nur von seiner Musik. In der Stadt der Barden hieß ihn willkommen, und endlich konnte er seine Musik spielen, ohne Angst zu haben. Doch dann kam der Drache. Er kann wegkommen, und seine neue Heimat retten.
### Waisenkind
Bard war ein Waise, der durch Musik großen Erfolg fand. Die Bewunderer waren aber kein Ersatz für eine Familie, die er sich immer gewünscht hat. Die Stadt der Barden war eine echte Heimat. Jetzt wird sie von einem Drachen angegriffen. Er kann den Drachen ablenken, und seine neue Heimat retten.
### Liebhaber
Dard verliebt sich oft, mit aller Macht, nur um sein Herz gebrochen zu bekommen. So oft war er Nummer 2, dass er sich immer aufs neue schwor, nicht mehr zu lieben, nur um den Schwur sofort zu brechen. In der Stadt der Barden fand er endlich die Liebe, nach der er sich sein ganzes Leben lang sehnte. Jetzt kommt der Drache, und er muss etwas tun, um seine Liebe zu retten.
### Säufer
Card war ein großer Barde, der Beste unter den Besten. Ruhm, Reichtum und Parties jede Nacht. Doch dann holte ihn irgendwann sein Alter ihn ein. Er wurde durchschnittlich! Jetzt säuft er die Tage weg, angewidert von der Mäßigkeit seiner eigenen Musik. Jetzt kommt der Drache, und es ist seine Chance, noch ein letztes Mal zu beweisen, dass er der Beste ist.
### Scharlatan
Eard war schon immer ein Großmaul das sich mit Lügen schmückt und Leute hinters Licht führt. Eines Tages behauptet er dem Drachen schon mal mit einer List problemlos entkommen zu sein. Als eine Gruppe Barden sich dann auf den Weg macht das Dorf vor dem Drachen zu retten, bitten sie ihn mitzukommen und hoffen auf seine Erfahrung und Expertise. Um die Lüge am Leben zu halten und sein Ansehen zu bewahren geht er mit ihnen auch wenn er eigentlich nicht will.
### Träumer
Fard hat schon immer davon geträumt der größte Barde aller Zeiten zu werden, doch bekam nie viel Beachtung bis er im Dorf der Barden ankam. Hier ist sein Traum zum greifen nah. Hier wird er zum größten Barden aller Zeiten denkt er sich. Und der größte Barde aller Zeiten wird natürlich sein Dorf beschützen und das Zeug dazu haben den Drachen mit seiner Musik zu besänftigen.
### Taugenichts
Gard war seinem Vater nie gut genug. Immer wurde er mit seinem erfolgreichen großen Bruder verglichen. Als sein Bruder eines tages dem Drachen zum Opfer fällt, fordert Gard's Vater Rache. Auch wenn es hoffnungslos scheint, macht sich Gard auf den Weg den Drachen zu töten um in die Fußstapfen seines Bruders zu treten und seinen Vater endlich stolz zu machen.
### Raufbold
Hard war schon immer hart drauf. Viel zu oft ließ er seine Fäuste seinen angestauten Emotionen Form verleihen. Nach zu vielen Tavernenschlägereien war er nur noch im Dorf der Barden willkommen. Dank den genau so emotionalen und ausgestoßenen Barden im Dorf fühlte er sich allerdings endlich mal verstanden. Er lernte seinen Gefühlen nicht mehr nur durch seine Fäuste, sondern auch durch seine Musik ein Ventil zu geben, doch der Drache der sein neues Zuhause bedroht lässt wieder die Wut in Hard überkochen.