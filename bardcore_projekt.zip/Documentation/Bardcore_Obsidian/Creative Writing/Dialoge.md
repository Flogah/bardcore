# Händler
1. Kommt ran, kommt ran! Nur die beste Ware. Naja, die beste Ware hier draußen.
2. Ah, fast hätte ich es weggepackt. Macht schnell, sonst holt er uns alle!
3. Alles hier ist gut! Denkt nicht zu lange nach, jeder Preis ist ein Gewinn.
4. Schon wieder? Naja, langt zu, bevor ich dicht mache.
5. Wisst ihr schon, was ihr braucht? Alles vom Feinsten.
6. Ha! Nur Barden. Könnt ihr euch meine Ware überhaupt leisten?
7. Normalerweise hasse ich Almosen. Heute ist keine Ausnahme.
8. Ihr seid soweit gekommen? Na, dann habt ihr es verdient, euch was zu kaufen!
9. Kommt ran, schaut euch um! Aber bitte mit den Augen.
10. Was, hier leben immer noch Leute? Ach, nur ihr. Kommt ran, nehmt was mit.
# Barden
## Alle 4
Pech: Soweit so gut. Wir hatten weniger Probleme als ich dachte.
Sauf: Es hätte sehr viel besser laufen können. Alleine wäre ich schon im Sumpf!
Wais: Alleine wären wir nirgendwo. Wir müssen zusammenhalten.
Love: Ja, vielleicht finden wir unterwegs auch Hilfe.

Sauf: Könnt ihr nicht schneller spielen?
Wais: Klar, aber dann würden deine Gichtfinger nicht mitkommen.
Love: Hört auf zu zanken! Alles ist gut, solange wir Takt halten.
Pech: Seid still! Ich glaube da vorne ist was.

Wais: Ich glaube ich war noch nie so lange mit anderen unterwegs.
Pech: Geht mir ähnlich. Eigentlich hätte schon lange was schlimmes passieren müssen.
Sauf: Bah, nichts wird passieren, solange ihr euch an mich haltet.
Love: Und wir Liebe im Herzen tragen!

Love: Ich hoffe dem Dorf geht es gut. Ich hoffe es geht -ihr- gut.
Wais: Natürlich geht es allen gut. Dafür sorgen wir.
Pech: Wir müssen nur unser Bestes geben!
Sauf: Rührend.
## Zu Zweit
### Pechmarie
Pech: Ich glaube mein Instrument ist verstimmt. Woher krieg ich jetzt ein Neues?
Sauf: Gib her, ich weiß wie es geht. Da, besser als neu.

Pech: Ich weiß nicht wo es lang geht. Haben wir uns verlaufen?
Wais: Keine Angst, wir finden den Weg. Wir sind nur verloren, wenn wir nicht zusammenhalten.

Pech: Ich vermisse das Dorf.
Love: Ich bin mir sicher, das Dorf vermisst dich auch. Bleib stark.
### Säufer
Sauf: Es ist ein Wunder dass du lange genug auf der Straße überlebt hast, um hier zu landen.
Pech: Ich kann halt mehr als Saiten zupfen und Purzelbäume.
Sauf: Also...!

Sauf: Warum wirfst du eigentlich dein Leben weg? Du verschwendest dein Talent.
Wais: Nur um zu werden wie du?

Sauf: All das für eine Liebe? Ich hatte so viele, ich weiß nicht mal mehr ihre Namen.
Love: Es ist es immer wert, mit vollem Herzen zu lieben.
### Waisenkind
Wais: Warst du schonmal wirklich einsam?
Sauf: Jeden Tag meines Lebens.

Wais: Liebe klingt so schwer. Ich wünschte, ich könnte sowas auch finden.
Love: Das wünsche ich dir auch. Vielleicht hast du es sogar schon.

Wais: Ich habe einen kleinen Glücksbringer gebastelt. Hier.
Pech: Danke! Hoffentlich hilft er uns allen.
### Liebhaber
Love: Ich habe viel von dir gehört. Wie war es, ganz oben zu sein?
Wais: Es war berauschend. Ich war unbesiegbar, unantastbar. Ich war ein Gott.
Love: Klingt einsam.
Wais: Verdammt einsam.

Love: Willst du keine Nachricht schreiben, für die Nachwelt?
Sauf: Alles Schreibenswerte wurde schon über mich verfasst. Niemand braucht das Gewäsch von einem alten Gerippe.

Love: Ich hoffe wir treffen uns im nächsten Leben!
Pech: Danke! Glaube ich...