Make a timeline
Be clear what happens which month (last month for thesis?)
Ask them to agree, but pushback is good, so the plan can be adjusted

**Scope smaller**
Write out the smallest scope
**List out every single asset**
Then put assets along the times

Common issues:
Timeline was set too short
One team member did not commit properly

Concept art probably not needed - go straight to producing assets

Big meeting for software dev
Google Software architecture documentation
Keep bringing up the software architecture
Set Naming conventions: folders, files
Keep adjusting the architecture to fit current needs, because needs can change

"Half of the job of a producer is reminding people"

Timeline will change, architecture

Challenge:
Game Designer needed, to actually make it fun - me?
Balance out combat/itemization with game design

Focus on team cohesion!
If i want things to continue, I need to make people want to be part of the team
## Keep motivation over efficiency

System for setting up good meetings
Kanban?
Meetings:
1. what was done this week?
2. what did we learn?
3. do we need to change architecture?
4. do we need to adjust the timeline?
5. shoot the shit, fun stuff

If an item doesn't move forward, how to tackle?
If it's a huge item, what's the underlying problem?
Is it because of perfectionism? Look at the timeline, get it to good enough, set a deadline
Laziness? Try to understand what's happening. 1-1, manage that person's motivation, identify the issue and move past it, maybe solve

GDD:
It's for keeping everyone in the same vibe
Adjust it, but maybe only for the same month