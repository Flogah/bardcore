Kosten sind abstrahiert.
0 = Tutorial
1 = Earlygame
2 = Midgame
3 = Lategame

| Name                                               | Upgrades                | Kosten | Vorteil                                                            |
| -------------------------------------------------- | ----------------------- | ------ | ------------------------------------------------------------------ |
| Gasthaus                                           |                         | 0      | Tutorial zum bauen. Startet das Spiel.                             |
| Instrumentenbauer (Fidel/ Trommel/ Fanfare/ Laute) |                         | 1      | Freischaltung Instrument. Pro Instrument ein Gebäude.              |
|                                                    | Instrumentenbauer Lvl 2 | 2      | Instrument Sidegrade (anderer Ton, anderer Look)                   |
| Orchestergraben                                    |                         | 1      | Upgrade Schaden/ Reichweite                                        |
| Tanzplatz                                          |                         | 1      | Upgrade HP                                                         |
| Theaterbühne                                       |                         | 1      | Freischaltung Items                                                |
|                                                    | Schneider               | 2      | Freischaltung mehr Rüstungsitems, Alternative Looks                |
|                                                    | Hutmacher               | 2      | Freischaltung mehr Helme                                           |
|                                                    | Schuhmacher             | 2      | Freischaltung mehr Schuhe, Mehr Bonuszeit zwischen Maps            |
|                                                    | Schmuckmacher           | 2      | Freischaltung mehr Ringe                                           |
| Gilde der Baumeister                               |                         | 2      | Verringert Kosten anderer Upgrades/ Erhöht verdiente Zeit nach Run |
| Aussichtsturm                                      |                         | 2      | Gibt mehr Zeit am Anfang, bevor der Countdown runterzählt.         |
|                                                    |                         |        |                                                                    |
