## Loop
Timer startet sofort, Warnung dass der Drache kommen wird in10:00!!
Timer ist Differenz Spieler Standort - Drache Standort, d.h. je schneller man sich bewegt, desto mehr Zeit gewinnt man.
### Erster Run
Es gibt eine Art Instrument (unterschiedlich gestimmte Instrumente der selben Art?)
Spieler nehmen ihr Instrument und gehen los.
Run dauert 7-10 Minuten
Jeder Spieler kann 1-2 Items looten.
Nach dem Run kann man 1 Gebäude um 1 Stufe verbessern. Dadurch schaltet man entweder mehr Items oder ein zweites Instrument frei.

### Zweiter Run
Spieler suchen wieder Instrumente aus.
Run dauert 10-15 Minuten
Spieler können 1-3 Items looten.
Man kann das andere Gebäude um 1 Stufe verbessern.
Weitere Upgrades brauchen Achievements.

### Dritter Run
Run dauert 10-15 Minuten
Spieler können 1-3 Items looten.
Spieler schaffen das Achievement.
Im Dorf, drittes Upgrades möglich.

### Vierter Run
Run dauert 15-20 Minuten
Spieler können 2-4 Items looten.
Spieler kommen zum ersten Boss.
Mehr Upgrades im Dorf.