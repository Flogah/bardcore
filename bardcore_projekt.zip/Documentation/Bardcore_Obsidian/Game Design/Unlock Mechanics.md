Es sollte nach jedem Run möglich sein, eine Sache zu upgraden (außer im späten Lategame).
D.h. entweder mehrere Upgrades die gleich viel kosten, oder Upgrades die sicherstellen, dass man den erhöhten Preis nach dem nächsten Run auch hinbekommen kann. [[Meta Loop]]

Man erhält für jede Minute die man überlebt verdient man 1 Tag.
7 Tage sind 1 Woche.
4 Wochen sind 1 Monat.

|           | Kosten min | Kosten max | umgerechnet | Notiz                                                          |
| --------- | ---------- | ---------- | ----------- | -------------------------------------------------------------- |
| Earlygame | 1 Woche    | 4 Wochen   | 7-28 Min    | Erste Runs, Keine Boni                                         |
| Midgame   | 2 Monate   | 6 Monate   | 56-168 Min  | Erster Boss wird regelmäßig besiegt                            |
| Lategame  | 7 Monate   | 1 Jahr     | 198-336 Min | Man hat den finalen Bosskampf gegen den Drachen freigeschaltet |
Tatsächliche Gametime wird gedeckelt bei 15 Minuten pro Welt. Alles darüber hinaus ist Bonuszeit, die direkt verdient wird statt Gametime zugeschrieben zu werden.

Mögliche Sachen um verdiente Zeit zu erhöhen:
Länger Überleben
Baugilde
Wachturm
Boss besiegen und ins nächste Gebiet