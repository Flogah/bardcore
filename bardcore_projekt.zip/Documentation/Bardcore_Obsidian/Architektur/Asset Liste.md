### Chars
- Entwurf: Säufer, Waisenkind, Liebhaber, Pechmarie, NPC (Fahrender Händler)
- Variationen
- Modeling, Texturing, Rigging?
### Items
- Implementation Design
- Item UI
- Loot Design
- 9 Items
- Extra Item Konzepte
### Kampfsystem
- Grundsystem (1 Instrument)
- Multiplayer Einbindung
- 2. Instrument
- Einbindung mit Item System
### Animation
- Laufen
- Dash/Dodge roll
- Angriff
- Verletzt
- Tod
- Einsammeln/Interagieren
### Production
- Maps
- Roguelite Loop Design
- Map Transition
- Save/Load
- Meta Progression
- Playtest Organisation