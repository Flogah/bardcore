Erstmal nur gesplittet in Monate
## Oktober
Chars: Artstyle finden, Blockout, 1 Charakter
Items: Konzepte!, Implementation Design
Kampf: Kampfkonzept, Grundbausteine, Dummy Sounds
Animation: Laufen, Interagieren
Prod: Multiplayer, Maps, Meta Loop Design
## November
Chars: 2 Charaktere
Items: Konzepte, Item Implementation, Loot Design
Kampf: Implementation 1. Instrument
Animation: Verletzt, Tod
Prod: Map Transition, Playtest
## Dezember
Chars: 2 Charaktere
Items: UI Entwurf, UI Implementation, 
Kampf: Implementation 2. Instrument
Animation: Angriff, Dash
Prod: Meta Progression, Save/Load
## Januar
Bugfixing, Polishing, Bachelor Arbeit!