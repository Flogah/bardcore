### Prio 1
Item Effekte
Action Kampfsystem
Zeitleisten UI zu Gameover
Coop Multiplayer
Verschiedene Charaktere (3D Chars)
Animation von Chars
### Prio 2
einfache Gegner
Dungeon 1 (nur Kampf)
Item pickup
Item Switchout
Dungeon 2 (mit Lootkiste)
### Prio 3
Verschiedene Instrumente
Hublevel (Dorf der Barden)
Hauptmenü
Instrumente zu Beginn auswechseln
Equipped Item Overlay
### Prio 4
Dynamischer Join
3D Welt
Meta Info bei Gameover
Metaprogression um mehr Items freizuschalten
Speichern/Laden von Metaprog