### Code Soll Sein
- Modular -> kurze Scripts
- Flexibel -> keine harten Dependencies
- Skalierbar
- Einfach mit Content erweiterbar
