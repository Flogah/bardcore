BARDCORE PROTOTYP
############################

Erstellt als Bachelorprojekt von
Ludwig Domberger
Marco Schaffer
Tomas Christmann
Svea Friz
Florian Gahler

#############################

In Bardcore spielt man Barden, die versuchen vor einem Drachen wegzulaufen.
Sobald möglich, versucht man weiter nach rechts zu laufen.
Wird man vom Drachen erwischt, landet man wieder im Dorf und kann Zeit ausgeben, um Gebäude zu bauen.

#############################

Um zu spielen:
Entpacken und exe ausführen.
Bardcore.pck muss im selben Ordner sein.

Im Hauptmenü 'Play' auswählen
LEERTASTE um dem Spiel beizutreten
ESC um ins Menü zurückzukehren
RESET um den Spielstand zurückzusetzen

#############################

Steuerung:
WASD und Maus um den Charakter zu steuern
QER um verschiedene Geschosse zu schießen
F um mit Dingen zu interagieren